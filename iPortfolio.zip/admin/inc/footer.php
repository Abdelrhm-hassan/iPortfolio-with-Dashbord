<footer class="tm-footer row tm-mt-small">
      <div class="col-12 font-weight-light">
        <p class="text-center text-white mb-0 px-4 small">
          Copyright &copy; <b><?php echo date('Y')?></b> All rights reserved. 
          
          Design: <a rel="nofollow noopener" href="#" class="tm-footer-link">Abdo Nagy</a>
        </p>
      </div>
    </footer>

    <script src="asset/js/jquery-3.3.1.min.js"></script>
    <!-- https://jquery.com/download/ -->
    <script src="asset/js/bootstrap.min.js"></script>
    <!-- https://getbootstrap.com/ -->
    <script>
   
    </script>
  </body>
</html>