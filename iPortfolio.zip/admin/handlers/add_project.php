<?php
session_start();

if(empty($_SESSION['name'])){
   header('location:login.php');
   }
// DB connection
include '../../config.php';

if(!isset($_POST['submit'])){
    header("location:../project.php");
}



$name=$_POST['name'];
$client=$_POST['c_name'];
$description=$_POST['descr'];
$time=$_POST['date'];

$data=date('Y-m-d H:i:s');
$img=$_FILES['img'];

$url=$_POST['url'];
// save img
$uploaddir = $_SERVER['DOCUMENT_ROOT'].'/iPortfolio/assets/img/portfolio';
     $img_name=$_FILES['img']['name'];
$uploadfile = $uploaddir .'/'.basename($_FILES['img']['name']);
echo $img_name;
 
if (move_uploaded_file($_FILES['img']['tmp_name'], $uploadfile)) {
   $msg = "File is valid, and was successfully uploaded.";
} else {
   $msg = "Error uploading!";
}
 



$sql="INSERT INTO `project` (`name`, `descr`, `c_name`, `date`, `img`, `url`)  VALUES ('$name', '$description', '$client', '$time','$img_name','$url') ";
$result=mysqli_query($conn, $sql);

if ($result) {

header("location:../project.php");

  }
  echo"faild";



  ?>